package com.auto.tasks.task1;


import com.auto.tasks.steps.tasksOneStepsDefinitions;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(SerenityRunner.class)
public class apiTests {
    @Steps
    tasksOneStepsDefinitions tasksOneStepsDefinitions;


    @Test
    public void listOfDogBreedsTest(){
       tasksOneStepsDefinitions.listDogBreeds();
       tasksOneStepsDefinitions.listDogBreadsStatusCode();
       tasksOneStepsDefinitions.listDogBreedsBody("success");
    }

    @Test
    public void verifyThatDogItIsOnTheList(){
        tasksOneStepsDefinitions.verifyThatTheDogisWithinTheList("retriever");
    }

    @Test
    public void getTheListOfSubBreedForRetriever(){
        tasksOneStepsDefinitions.listOfSubBreedsFor("retriever");
    }

    @Test
    public void produceRandomImage(){
        tasksOneStepsDefinitions.linkForSubBreadImage("success");
    }


}
