package com.auto.tasks.steps;

import net.thucydides.core.annotations.Step;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;

import static org.hamcrest.Matchers.*;

public class tasksOneStepsDefinitions {
    private Response response;

    @Step
    public void listDogBreeds(){
        response = SerenityRest.when().get("https://dog.ceo/api/breeds/list/all ");
    }

    @Step
    public void listDogBreadsStatusCode(){
        response.then().statusCode(200);
    }

    @Step
    public void listDogBreedsBody(String status){
        response.then().body("status",is(status));
    }

    @Step
    public void verifyThatTheDogisWithinTheList(String name){
        response.then().body("message",hasKey(name));
    }

    @Step
    public void listOfSubBreedsFor(String breed){
        Response response;
        response = SerenityRest.when().get("https://dog.ceo/api/breed/"+breed+"/list");
        response.then().body("message",hasItem("golden"));
    }

    @Step
    public void linkForSubBreadImage(String subBreed){
        Response response;
        response = SerenityRest.when().get("https://dog.ceo/api/breeds/image/random");
        response.then().body("status",is(subBreed));
    }

}
